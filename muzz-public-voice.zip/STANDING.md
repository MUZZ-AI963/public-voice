# Public Voice · Standing commit · 15 Nov 2026

**Status:** Learning standing commit for Cursor Auto on this product. Re-read every Public Voice chat. invent-for-P still forbidden. Cont invent leave alone. Cursor contacts no one.

## The people’s go-to

Public Voice is the free place everyone can come to **sound out** government, agency, and corporate *public* publications that do not stack with past public information — anonymously if they choose — and put a checkable pack **on that desk** to explain.

AI is invited as **guidance and control for the people**: machine-speed access to history, published law pages, Hansard, media transcripts, and open portals — so mismatches, silence clocks, redirection, and **rehash that never transpired** become visible. Where institutional controls try to keep that assist away from people, this platform keeps the assist **on the people’s side**.

## Identification (who is named)

**No public-role speaker is spared** when there is **lawful and reasonable cause** on the *public record*:

- Name them by **public role, organisation, and the primary-source URL** of what they said or signed.
- That is identification of the **microphone**, not a private-life hunt.

**Still forbidden (keeps the platform alive):**

- Private home, personal phone, private email, family, or junior-staff targeting.
- Classified / unlawfully obtained material.
- Auto-lodging to tip lines or courts.
- Publishing “guilty,” “corrupt,” or “you have a cause of action” as a platform finding.

## Truth and legal recourse (how we say it)

- **Truth on the ledger** = what primary sources show side-by-side (claim → source → counter / empty event / silence). AI proposes; sources publish.
- **Legal recourse on the ledger** = **pathways** made public: FOI/OIA/FOIA clocks, Ombudsman, parliamentary complaint, published regulator forms, corporate grievance URLs — with the same Draft · not lodged Send packs. The page does **not** give legal advice and does **not** decide standing or liability. Readers and their advisers judge.

## AI role (standing)

| AI does | AI does not |
|---|---|
| Retrieve and align public history, Hansard, media, statutes *as published* | Become the source of “not true” |
| Flag contradiction, silence-past-clock, rehash-unanchored | Convict or sentence |
| Draft spotlight + explain-ask + pathway checklist | Lodge, dox, or contact anyone |
| Run at machine speed for everyone | Replace human publish control or correction path |

EU/UK transparency norms: when AI text informs the public on public-interest matters, disclose assist + keep human review on publish (AI Act Art. 50 spirit). Our packs already mark `auth.method`.

## Every laptop worldwide

Must run on **any laptop** with a modern browser — Windows, Mac, Linux, Chromebook — no app store, no account.

- **Hosted HTTPS** (Pages / mirrors) = default go-to URL for everyone.  
- **Zip + local server** = USB / offline lab.  
- **PWA** = install on laptop after first HTTPS visit; shell works offline.  
- **Mirror hosts** welcome under LICENSE.

Seal needs `https://` or `http://127.0.0.1`. See `GET.md` and `onboarding.html`.

## Operator face

Anonymous operators on the public UI. Company LICENSE may remain for free hosting. No personal names on the people’s face.
