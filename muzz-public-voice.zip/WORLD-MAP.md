# Public Voice · World map · what we need to make the go-to real

**Date:** 15 Nov 2026 · Australia/Brisbane  
**Purpose:** Deep dive → build list. Primary open feeds only. Cursor contacts no one.

## North star

Everyone can open Public Voice, see authenticated public statements (and silence), see **who held the microphone**, see **pathways** for lawful follow-up, and — when they choose — sound out anonymously with AI assist at machine speed.

## Layer cake (build in this order)

| Layer | Job | Status |
|---|---|---|
| A · Desk + seal + static gallery | Person sounds out; export sealed pack | **Have** (`docs/public-voice/`) |
| A2 · Every laptop | HTTPS + PWA offline + zip + mirrors | **Have** (sw.js, onboarding, `muzz-public-voice.zip`, `GET.md`) — Pages live when Murray says |
| B · Append-only publish | People publish without hand-copy | Open when Murray says (Forms→PR / Pages) |
| C · Source registry | Curated list of primary feeds by country | **Start now** (`sources-registry.json`) |
| D · Identity index | Public-role speakers ↔ org ↔ official page / Hansard id | Next: Popolo-shaped stubs |
| E · AI matcher | Suggest claim↔counter from registry + fetch | Next eng: offline/browser-assist prototype |
| F · Pathway engine | Map auth status → FOI/ombudsman/corp grievance Send packs | Partial in desk; expand jurisdictions |
| G · Global gallery + search | Everyone’s go-to browse | After B + C |
| H · Correction lane | Subject sourced reply, both visible | Phase B+ |

## Primary feeds discovered (machine-readable where possible)

### Parliament / Hansard (claim text + speaker)

| Region | Feed | Notes |
|---|---|---|
| NSW AU | `https://api.parliament.nsw.gov.au/api/hansard/...` | Speakers, fragments, PDF; 1991– |
| UK | `https://api.parliament.uk/` · Historic Hansard `.js` · developer.parliament.uk | Open Parliament Licence |
| UK civic | TheyWorkForYou API | Debates/WMS; key required; **no private politician contacts via API** (good fence) |
| EU | `https://data.europarl.europa.eu/api/v2` | MEPs, speeches, procedures; rate limit 500/5min |
| US | Congress.gov / govinfo (confirm live endpoints before coding) | Prefer official over dead Sunlight paths |
| Multi | EveryPolitician Popolo JSON | Legislature membership identity — **public roles**, not homes |

### Official publications / media

| Kind | Approach |
|---|---|
| Ministerial media releases | Agency RSS / media centre HTML → URL + date + quote hash |
| Corporate ASX/SEC filings | Company announcement URLs as primary for corp door |
| Press video/transcript | Only with stable public URL (broadcaster or official transcript) |

### Claim interoperability

| Resource | Use |
|---|---|
| Schema.org **ClaimReview** | Align our `claims[]` + `auth` export for discovery |
| Fact-Check Insights / ClaimReview corpora | Research/compare; **do not** treat third-party ratings as our seal; link as optional counter_url when primary |

### Pathways (recourse, not advice)

Already sketched in `jurisdictions.json` for AU/NZ/UK/US FOI + Ombudsman. Expand next:

- AU states FOI + Ombudsman URLs  
- CA / EU member DPAs (pointer pages, not invented clocks)  
- Corporate: published complaints / whistleblowing *policy URLs* only (person pastes; we don’t lodge)

## Identification model (lawful)

```
subject = {
  role,              // Minister, CEO, FOI decision-maker (public title)
  org,               // Department / company as published
  public_office,     // Official URL or published switchboard only
  public_id          // optional: Hansard member id, MEP id, Popolo id
}
```

**Identify** whenever a pack authenticates a statement to that microphone.  
**Never store** private residential/phone fields (auto-reject already).

## AI matcher (what to build)

1. **Input:** claim text + country + door (+ optional org).  
2. **Retrieve:** registry endpoints + user-pasted URLs (browser or later thin relay).  
3. **Propose:** up to N counter candidates with URL, date, excerpt, similarity note.  
4. **Human holds publish:** person accepts/rejects; pack stores only chosen primary URLs.  
5. **Label:** `auth.method = ai_assisted_primary` + disclosure line on gallery card.  
6. **Pathway suggest:** from `auth.status` + country → Send pack channel list (already started).

No autonomous public drop of AI-only verdicts. No contact to subjects by Cursor.

## Legal / regulatory watch (standing, not advice)

- Public-interest journalism / accountability of *public* speech is a recognised interest (e.g. ICO journalism code factors: transparency, preventing people being misled). We stay in **public sources + structural status + pathways**.  
- EU AI Act Art. 50 spirit: disclose AI-assisted public-interest text unless human editorial control — we keep human publish + `method` field.  
- Defamation / safe harbour varies by country: **primary URL + no guilt finding + correction path** is the eng posture that keeps the go-to alive.

## Put-in-use sequence (next slices)

1. Ship `sources-registry.json` (this pass).  
2. Schema: `subjects[].public_id`, `recourse[]` pathways.  
3. Desk: show pathway checklist from auth status.  
4. When Murray opens Pages: gallery live + anonymous packs.  
5. AI matcher prototype (browser-side first: paste two URLs → diff/spotlight draft).  
6. Country packs: AU Commonwealth + one state; UK; US FOIA.gov; EU pointer.

## Hard fences (unchanged)

Primary source or no publish · no doxx · no classified · person controls publish · we do not lodge · not legal advice · invent-for-P forbidden · Cursor contacts no one.
